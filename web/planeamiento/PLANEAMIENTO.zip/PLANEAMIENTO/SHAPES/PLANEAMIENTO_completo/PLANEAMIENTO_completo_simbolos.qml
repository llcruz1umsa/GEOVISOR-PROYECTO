<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="0" maxScale="0" autoRefreshTime="0" version="3.44.14-Solothurn" simplifyAlgorithm="0" simplifyMaxScale="1" symbologyReferenceScale="-1" simplifyDrawingTol="1" simplifyDrawingHints="1" hasScaleBasedVisibilityFlag="0" simplifyLocal="1" readOnly="0" styleCategories="AllStyleCategories" minScale="100000000" autoRefreshMode="Disabled">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal accumulate="0" startExpression="" fixedDuration="0" durationUnit="min" mode="0" durationField="" endField="" enabled="0" limitMode="0" startField="" endExpression="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zscale="1" clamping="Terrain" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" symbology="Line" zoffset="0" type="IndividualFeatures" extrusion="0" customToleranceEnabled="0" binding="Centroid" extrusionEnabled="0">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol clip_to_extent="1" alpha="1" name="" frame_rate="10" type="line" force_rhr="0" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" id="{e4a28efb-9386-41ea-8044-9fe3f6abe963}" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="125,139,143,255,rgb:0.4901961,0.545098,0.5607843,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol clip_to_extent="1" alpha="1" name="" frame_rate="10" type="fill" force_rhr="0" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" id="{0d5bdf89-fc94-4d8d-a6a9-3417c80e8e8d}" class="SimpleFill" enabled="1">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="125,139,143,255,rgb:0.4901961,0.545098,0.5607843,1" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="89,99,102,255,rgb:0.3501335,0.3893492,0.4005493,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol clip_to_extent="1" alpha="1" name="" frame_rate="10" type="marker" force_rhr="0" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" id="{ac7fba61-afbd-4432-8e1b-8335005a4bd9}" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="125,139,143,255,rgb:0.4901961,0.545098,0.5607843,1" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="89,99,102,255,rgb:0.3501335,0.3893492,0.4005493,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 symbollevels="0" forceraster="0" referencescale="-1" type="singleSymbol" enableorderby="0">
    <symbols>
      <symbol clip_to_extent="1" alpha="1" name="0" frame_rate="10" type="marker" force_rhr="0" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties" type="Map">
              <Option name="alpha" type="Map">
                <Option value="true" name="active" type="bool"/>
                <Option value="coalesce(&quot;opacidad&quot;,100)" name="expression" type="QString"/>
                <Option value="3" name="type" type="int"/>
              </Option>
            </Option>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" id="{9a6ec61b-62b0-4d98-b79a-04b1b547a406}" class="SvgMarker" enabled="1">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="color" type="QString"/>
            <Option value="0" name="fixedAspectRatio" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="C:/SIG 2/PLANEAMIENTO/simbolos/unidad.svg" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255,rgb:0,0,0,1" name="outline_color" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option name="parameters"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="600" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MapUnit" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="angle" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;rotacion&quot;,0)" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="fillColor" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN &quot;bando&quot;='Enemigo' THEN '#e00000' WHEN &quot;bando&quot;='Obstáculo' THEN '#00a030' WHEN &quot;bando&quot;='Contaminado' THEN '#e6c800' WHEN &quot;bando&quot;='Negro' THEN '#000000' ELSE '#0033cc' END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="name" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="file_path(layer_property(@layer,'path')) || '/simbolos/' || coalesce(&quot;simbolo&quot;,'unidad') || if(coalesce(&quot;previsto&quot;,0)=1,'_p','') || '.svg'" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="outlineColor" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN &quot;bando&quot;='Enemigo' THEN '#e00000' WHEN &quot;bando&quot;='Obstáculo' THEN '#00a030' WHEN &quot;bando&quot;='Contaminado' THEN '#e6c800' WHEN &quot;bando&quot;='Negro' THEN '#000000' ELSE '#0033cc' END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="size" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;tamano&quot;,600)" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="0" id="{740cc482-6bcb-4c94-a291-4ba17e4ebea9}" class="FontMarker" enabled="1">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="X" name="chr" type="QString"/>
            <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="color" type="QString"/>
            <Option value="Arial" name="font" type="QString"/>
            <Option value="Bold" name="font_style" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="miter" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MapUnit" name="offset_unit" type="QString"/>
            <Option value="255,255,255,255,rgb:1,1,1,1" name="outline_color" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="60" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MapUnit" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="char" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;escalon&quot;,'')" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="enabled" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="length(coalesce(&quot;escalon&quot;,''))>0" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="fillColor" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN &quot;bando&quot;='Enemigo' THEN '#e00000' WHEN &quot;bando&quot;='Obstáculo' THEN '#00a030' WHEN &quot;bando&quot;='Contaminado' THEN '#e6c800' WHEN &quot;bando&quot;='Negro' THEN '#000000' ELSE '#0033cc' END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="offset" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="to_string(coalesce(&quot;tamano&quot;,600)*0)||','||to_string(coalesce(&quot;tamano&quot;,600)*-0.31)" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="size" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;tamano&quot;,600)*0.11" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="0" id="{928f11b1-1d6f-489a-8b9a-08497fa345de}" class="FontMarker" enabled="1">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="X" name="chr" type="QString"/>
            <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="color" type="QString"/>
            <Option value="Arial" name="font" type="QString"/>
            <Option value="Bold" name="font_style" type="QString"/>
            <Option value="2" name="horizontal_anchor_point" type="QString"/>
            <Option value="miter" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MapUnit" name="offset_unit" type="QString"/>
            <Option value="255,255,255,255,rgb:1,1,1,1" name="outline_color" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="60" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MapUnit" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="char" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;desig_izq&quot;,'')" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="enabled" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="length(coalesce(&quot;desig_izq&quot;,''))>0" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="fillColor" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN &quot;bando&quot;='Enemigo' THEN '#e00000' WHEN &quot;bando&quot;='Obstáculo' THEN '#00a030' WHEN &quot;bando&quot;='Contaminado' THEN '#e6c800' WHEN &quot;bando&quot;='Negro' THEN '#000000' ELSE '#0033cc' END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="offset" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="to_string(coalesce(&quot;tamano&quot;,600)*-0.38)||','||to_string(coalesce(&quot;tamano&quot;,600)*0)" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="size" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;tamano&quot;,600)*0.11" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="0" id="{088d04bf-c230-429a-bb21-58315a068d66}" class="FontMarker" enabled="1">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="X" name="chr" type="QString"/>
            <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="color" type="QString"/>
            <Option value="Arial" name="font" type="QString"/>
            <Option value="Bold" name="font_style" type="QString"/>
            <Option value="0" name="horizontal_anchor_point" type="QString"/>
            <Option value="miter" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MapUnit" name="offset_unit" type="QString"/>
            <Option value="255,255,255,255,rgb:1,1,1,1" name="outline_color" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="60" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MapUnit" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="char" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;desig_der&quot;,'')" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="enabled" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="length(coalesce(&quot;desig_der&quot;,''))>0" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="fillColor" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN &quot;bando&quot;='Enemigo' THEN '#e00000' WHEN &quot;bando&quot;='Obstáculo' THEN '#00a030' WHEN &quot;bando&quot;='Contaminado' THEN '#e6c800' WHEN &quot;bando&quot;='Negro' THEN '#000000' ELSE '#0033cc' END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="offset" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="to_string(coalesce(&quot;tamano&quot;,600)*0.38)||','||to_string(coalesce(&quot;tamano&quot;,600)*0)" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="size" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;tamano&quot;,600)*0.11" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="0" id="{b9330c63-4284-4237-8b75-3798986ec2dd}" class="FontMarker" enabled="1">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="X" name="chr" type="QString"/>
            <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="color" type="QString"/>
            <Option value="Arial" name="font" type="QString"/>
            <Option value="Bold" name="font_style" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="miter" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MapUnit" name="offset_unit" type="QString"/>
            <Option value="255,255,255,255,rgb:1,1,1,1" name="outline_color" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="60" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MapUnit" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="char" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;texto_cent&quot;,'')" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="enabled" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="length(coalesce(&quot;texto_cent&quot;,''))>0" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="fillColor" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN &quot;bando&quot;='Enemigo' THEN '#e00000' WHEN &quot;bando&quot;='Obstáculo' THEN '#00a030' WHEN &quot;bando&quot;='Contaminado' THEN '#e6c800' WHEN &quot;bando&quot;='Negro' THEN '#000000' ELSE '#0033cc' END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="offset" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="to_string(coalesce(&quot;tamano&quot;,600)*0)||','||to_string(coalesce(&quot;tamano&quot;,600)*0)" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="size" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;tamano&quot;,600)*0.15" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="0" id="{b01662b3-58f4-4418-86b3-cee92f91e5af}" class="FontMarker" enabled="1">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="X" name="chr" type="QString"/>
            <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="color" type="QString"/>
            <Option value="Arial" name="font" type="QString"/>
            <Option value="Bold" name="font_style" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="miter" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MapUnit" name="offset_unit" type="QString"/>
            <Option value="255,255,255,255,rgb:1,1,1,1" name="outline_color" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="60" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MapUnit" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="char" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;texto_abaj&quot;,'')" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="enabled" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="length(coalesce(&quot;texto_abaj&quot;,''))>0" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="fillColor" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN &quot;bando&quot;='Enemigo' THEN '#e00000' WHEN &quot;bando&quot;='Obstáculo' THEN '#00a030' WHEN &quot;bando&quot;='Contaminado' THEN '#e6c800' WHEN &quot;bando&quot;='Negro' THEN '#000000' ELSE '#0033cc' END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="offset" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="to_string(coalesce(&quot;tamano&quot;,600)*0)||','||to_string(coalesce(&quot;tamano&quot;,600)*0.31)" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="size" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="coalesce(&quot;tamano&quot;,600)*0.1" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option value="" type="QString"/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="fid" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="simbolo" configurationFlags="NoFlag">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option value="unidad" name="01 · Unidad" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="instalacion" name="01 · Instalación, SPAC o Puesto" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="puesto_comando" name="01 · Puesto Comando" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="puesto_observacion" name="01 · Puesto de observación" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_inf" name="02 · Unidad de Infantería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_art" name="02 · Unidad de Artillería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_cab" name="02 · Unidad de Caballería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_ing" name="02 · Unidad de Ingeniería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_com" name="02 · Unidad de Comunicaciones" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_avi" name="02 · Unidad de Aviación" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_ave" name="02 · Unidad de Aviación del Ejército" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_arm" name="02 · Unidad de Armada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_aem" name="03 · Unidad Aeromóvil" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_aet" name="03 · Unidad Aerotransportada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_and" name="03 · Unidad Andina" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_bli" name="03 · Unidad Blindada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_mot" name="03 · Unidad Motorizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_anf" name="03 · Unidad Anfibia" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_sel" name="03 · Unidad de Selva" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_aaa" name="03 · Unidad de Artillería Antiaérea" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_cos" name="03 · Unidad de Artillería de Costa" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_im" name="03 · Unidad de Inteligencia Militar" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_asa" name="03 · Unidad de Fuerzas de Asalto" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_pm" name="04 · Unidad de Policía Militar" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_pos" name="04 · Unidad de Servicio Postal" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_pag" name="04 · Unidad de Pagaduría" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_bm" name="04 · Unidad de Banda de Música" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_rel" name="04 · Unidad de Servicio Religioso" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_jus" name="04 · Unidad de Justicia" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_int" name="04 · Unidad de Intendencia" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_mb" name="04 · Unidad de Material Bélico" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_san" name="04 · Unidad de Sanidad" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_tra" name="04 · Unidad de Transporte Motorizado" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_man" name="04 · Unidad de Mantenimiento" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_vet" name="04 · Unidad de Veterinaria" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_ext" name="05 · Puesto de Extraviados" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_mue" name="05 · Puesto de Reunión de Muertos" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_cem" name="05 · Cementerio" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_pg" name="05 · Puesto de Prisioneros de Guerra" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_ref" name="05 · Puesto de Refugiados o Internados" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_c1" name="05 · Puesto de Clase I" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_c24" name="05 · Puesto de Clase II y IV" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_c3" name="05 · Puesto de Clase III" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_c5" name="05 · Puesto de Clase V" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_mb" name="05 · Puesto de Material Bélico" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_san" name="05 · Puesto de Sanidad" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_ing" name="05 · Puesto de Materiales de Ingeniería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_int" name="05 · Puesto de Intendencia" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_man" name="05 · Puesto de Mantenimiento" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_tra" name="05 · Puesto de Transporte" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="p_pm" name="05 · Puesto de Policía Militar" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_inf_aet" name="06 · Infantería Aerotransportada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_inf_bli" name="06 · Infantería Mecanizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_inf_and" name="06 · Infantería Andina" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_inf_sel" name="06 · Infantería de Selva" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_inf_mot" name="06 · Infantería Motorizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_art_aet" name="06 · Artillería Aerotransportada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_art_bli" name="06 · Artillería Mecanizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_art_and" name="06 · Artillería Andina" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_art_sel" name="06 · Artillería de Selva" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_art_mot" name="06 · Artillería Motorizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_cab_bli" name="06 · Caballería Mecanizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_cab_and" name="06 · Caballería Andina" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_cab_sel" name="06 · Caballería de Selva" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_cab_mot" name="06 · Caballería Motorizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_com_aet" name="06 · Comunicaciones Aerotransportada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_com_bli" name="06 · Comunicaciones Mecanizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_com_and" name="06 · Comunicaciones Andina" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_com_mot" name="06 · Comunicaciones Motorizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_ing_aet" name="06 · Ingeniería Aerotransportada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_ing_and" name="06 · Ingeniería Andina" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_ing_sel" name="06 · Ingeniería de Selva" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_ing_bli" name="06 · Ingeniería Mecanizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_ing_mot" name="06 · Ingeniería Motorizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_ing_anf" name="06 · Ingeniería Anfibia" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_int_aet" name="06 · Intendencia Aerotransportada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_int_aem" name="06 · Intendencia Aeromóvil" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_int_bli" name="06 · Intendencia Mecanizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_int_and" name="06 · Intendencia Andina" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_int_mot" name="06 · Intendencia Motorizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_mb_aet" name="06 · Material Bélico Aerotransportada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_mb_and" name="06 · Material Bélico Andina" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_san_bli" name="06 · Sanidad Mecanizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_san_and" name="06 · Sanidad Andina" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_san_mot" name="06 · Sanidad Motorizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_pm_aet" name="06 · Policía Militar Aerotransportada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_pm_aem" name="06 · Policía Militar Aeromóvil" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_pm_bli" name="06 · Policía Militar Mecanizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_pm_and" name="06 · Policía Militar Andina" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="u_pm_mot" name="06 · Policía Militar Motorizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pc_inf" name="07 · Puesto Comando de Infantería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pc_art" name="07 · Puesto Comando de Artillería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pc_cab" name="07 · Puesto Comando de Caballería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pc_ing" name="07 · Puesto Comando de Ingeniería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pc_com" name="07 · Puesto Comando de Comunicaciones" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pto_comprobacion" name="08 · Punto de comprobación (n.º o letra al centro)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pto_contacto" name="08 · Punto de contacto (n.º al centro)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pto_coordinacion" name="08 · Punto de coordinación / punto límite" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pto_enlace" name="08 · Punto de enlace o control" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pto_pasaje" name="08 · Punto de pasaje (PP al centro)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pto_relevo" name="08 · Punto de relevo" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="pto_critico" name="08 · Punto crítico (n.º al centro)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="objetivo" name="08 · Objetivo (O1, Oa… al centro)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="objetivo_dos" name="08 · Objetivo a conquistar por dos unidades" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="mina_desc" name="09 · Mina de tipo desconocido" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="mina_ap" name="09 · Mina antipersonal de presión" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="mina_at" name="09 · Mina antitanque activa" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="mina_at_doble" name="09 · Mina antitanque doble" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="trampa" name="09 · Trampa explosiva" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="abrigo_ind" name="10 · Abrigo individual" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="abrigo_col" name="10 · Abrigo colectivo" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="emplazamiento" name="10 · Emplazamiento de arma o pozo de tirador" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="trinchera" name="10 · Trinchera con pozo de tirador" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_unidad" name="11 · Unidad enemiga (rombo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_art" name="11 · Unidad de artillería enemiga (rombo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_instalacion" name="11 · Instalación enemiga (trazo doble)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_po" name="11 · Puesto de observación enemigo (trazo doble)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_inf" name="12 · Unidad enemiga de Infantería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_art" name="12 · Unidad enemiga de Artillería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_cab" name="12 · Unidad enemiga de Caballería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_ing" name="12 · Unidad enemiga de Ingeniería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_com" name="12 · Unidad enemiga de Comunicaciones" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_avi" name="12 · Unidad enemiga de Aviación" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_ave" name="12 · Unidad enemiga de Aviación del Ejército" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_arm" name="12 · Unidad enemiga de Armada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_aem" name="13 · Unidad enemiga Aeromóvil" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_aet" name="13 · Unidad enemiga Aerotransportada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_and" name="13 · Unidad enemiga Andina" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_bli" name="13 · Unidad enemiga Blindada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_mot" name="13 · Unidad enemiga Motorizada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_anf" name="13 · Unidad enemiga Anfibia" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_sel" name="13 · Unidad enemiga de Selva" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_aaa" name="13 · Unidad enemiga de Artillería Antiaérea" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_cos" name="13 · Unidad enemiga de Artillería de Costa" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_im" name="13 · Unidad enemiga de Inteligencia Militar" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_asa" name="13 · Unidad enemiga de Fuerzas de Asalto" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_pm" name="14 · Unidad enemiga de Policía Militar" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_pos" name="14 · Unidad enemiga de Servicio Postal" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_pag" name="14 · Unidad enemiga de Pagaduría" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_bm" name="14 · Unidad enemiga de Banda de Música" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_rel" name="14 · Unidad enemiga de Servicio Religioso" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_jus" name="14 · Unidad enemiga de Justicia" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_int" name="14 · Unidad enemiga de Intendencia" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_mb" name="14 · Unidad enemiga de Material Bélico" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_san" name="14 · Unidad enemiga de Sanidad" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_tra" name="14 · Unidad enemiga de Transporte Motorizado" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_man" name="14 · Unidad enemiga de Mantenimiento" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_vet" name="14 · Unidad enemiga de Veterinaria" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_inf_aet" name="15 · Infantería Aerotransportada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_inf_bli" name="15 · Infantería Mecanizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_inf_and" name="15 · Infantería Andina (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_inf_sel" name="15 · Infantería de Selva (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_inf_mot" name="15 · Infantería Motorizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_art_aet" name="15 · Artillería Aerotransportada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_art_bli" name="15 · Artillería Mecanizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_art_and" name="15 · Artillería Andina (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_art_sel" name="15 · Artillería de Selva (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_art_mot" name="15 · Artillería Motorizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_cab_bli" name="15 · Caballería Mecanizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_cab_and" name="15 · Caballería Andina (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_cab_sel" name="15 · Caballería de Selva (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_cab_mot" name="15 · Caballería Motorizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_com_aet" name="15 · Comunicaciones Aerotransportada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_com_bli" name="15 · Comunicaciones Mecanizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_com_and" name="15 · Comunicaciones Andina (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_com_mot" name="15 · Comunicaciones Motorizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_ing_aet" name="15 · Ingeniería Aerotransportada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_ing_and" name="15 · Ingeniería Andina (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_ing_sel" name="15 · Ingeniería de Selva (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_ing_bli" name="15 · Ingeniería Mecanizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_ing_mot" name="15 · Ingeniería Motorizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_ing_anf" name="15 · Ingeniería Anfibia (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_int_aet" name="15 · Intendencia Aerotransportada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_int_aem" name="15 · Intendencia Aeromóvil (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_int_bli" name="15 · Intendencia Mecanizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_int_and" name="15 · Intendencia Andina (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_int_mot" name="15 · Intendencia Motorizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_mb_aet" name="15 · Material Bélico Aerotransportada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_mb_and" name="15 · Material Bélico Andina (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_san_bli" name="15 · Sanidad Mecanizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_san_and" name="15 · Sanidad Andina (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_san_mot" name="15 · Sanidad Motorizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_pm_aet" name="15 · Policía Militar Aerotransportada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_pm_aem" name="15 · Policía Militar Aeromóvil (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_pm_bli" name="15 · Policía Militar Mecanizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_pm_and" name="15 · Policía Militar Andina (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_u_pm_mot" name="15 · Policía Militar Motorizada (enemigo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_pc_inf" name="16 · Puesto Comando enemigo de Infantería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_pc_art" name="16 · Puesto Comando enemigo de Artillería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_pc_cab" name="16 · Puesto Comando enemigo de Caballería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_pc_ing" name="16 · Puesto Comando enemigo de Ingeniería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="eno_pc_com" name="16 · Puesto Comando enemigo de Comunicaciones" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="bando" configurationFlags="NoFlag">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option value="Propio" name="Propio (azul)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="Enemigo" name="Enemigo (rojo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="Obstáculo" name="Obstáculo (verde)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="Contaminado" name="Contaminado (amarillo)" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="Negro" name="Obras y poblaciones (negro)" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="escalon" configurationFlags="NoFlag">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="(sin escalón)" type="invalid"/>
              </Option>
              <Option type="Map">
                <Option value="XXXXXX" name="XXXXXX  Comando General del Ejército" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="XXXXX" name="XXXXX  Comando del TO / ZI" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="XXXX" name="XXXX  Comando FF.TT. del TO" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="XXX" name="XXX  Cuerpo de Ejército" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="XX" name="XX  División" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="X" name="X  Brigada" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="III" name="III  Regimiento" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="II" name="II  Batallón / Grupo" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="I" name="I  Compañía / Escuadrón / Batería" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="●●" name="●●  Sección" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="●" name="●  Escuadra" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="▲" name="▲  Equipo" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="desig_izq" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="desig_der" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="texto_cent" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="texto_abaj" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="previsto" configurationFlags="NoFlag">
      <editWidget type="CheckBox">
        <config>
          <Option type="Map">
            <Option value="1" name="CheckedState" type="QString"/>
            <Option value="0" name="UncheckedState" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="tamano" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="rotacion" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="obs" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="opacidad" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" name="" field="fid"/>
    <alias index="1" name="Símbolo" field="simbolo"/>
    <alias index="2" name="Bando / color" field="bando"/>
    <alias index="3" name="Magnitud de escalón" field="escalon"/>
    <alias index="4" name="Designación (izquierda)" field="desig_izq"/>
    <alias index="5" name="Designación (derecha)" field="desig_der"/>
    <alias index="6" name="Texto al centro" field="texto_cent"/>
    <alias index="7" name="Calibre / texto abajo" field="texto_abaj"/>
    <alias index="8" name="Previsto o futuro (línea entrecortada)" field="previsto"/>
    <alias index="9" name="Tamaño (metros)" field="tamano"/>
    <alias index="10" name="Rotación (°)" field="rotacion"/>
    <alias index="11" name="Observaciones" field="obs"/>
    <alias index="12" name="Opacidad (%)" field="opacidad"/>
  </aliases>
  <defaults>
    <default expression="" applyOnUpdate="0" field="fid"/>
    <default expression="'unidad'" applyOnUpdate="0" field="simbolo"/>
    <default expression="'Propio'" applyOnUpdate="0" field="bando"/>
    <default expression="" applyOnUpdate="0" field="escalon"/>
    <default expression="" applyOnUpdate="0" field="desig_izq"/>
    <default expression="" applyOnUpdate="0" field="desig_der"/>
    <default expression="" applyOnUpdate="0" field="texto_cent"/>
    <default expression="" applyOnUpdate="0" field="texto_abaj"/>
    <default expression="0" applyOnUpdate="0" field="previsto"/>
    <default expression="round(coalesce(@map_scale,50000)*0.012)" applyOnUpdate="0" field="tamano"/>
    <default expression="0" applyOnUpdate="0" field="rotacion"/>
    <default expression="" applyOnUpdate="0" field="obs"/>
    <default expression="100" applyOnUpdate="0" field="opacidad"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" notnull_strength="1" constraints="3" field="fid" unique_strength="1"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="simbolo" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="bando" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="escalon" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="desig_izq" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="desig_der" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="texto_cent" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="texto_abaj" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="previsto" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="tamano" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="rotacion" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="obs" unique_strength="0"/>
    <constraint exp_strength="0" notnull_strength="0" constraints="0" field="opacidad" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="fid"/>
    <constraint desc="" exp="" field="simbolo"/>
    <constraint desc="" exp="" field="bando"/>
    <constraint desc="" exp="" field="escalon"/>
    <constraint desc="" exp="" field="desig_izq"/>
    <constraint desc="" exp="" field="desig_der"/>
    <constraint desc="" exp="" field="texto_cent"/>
    <constraint desc="" exp="" field="texto_abaj"/>
    <constraint desc="" exp="" field="previsto"/>
    <constraint desc="" exp="" field="tamano"/>
    <constraint desc="" exp="" field="rotacion"/>
    <constraint desc="" exp="" field="obs"/>
    <constraint desc="" exp="" field="opacidad"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortExpression="" sortOrder="0" actionWidgetStyle="dropDown">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1">&lt;!--auto_tabla-->&lt;!--chico-->&lt;div style="font-family:'Segoe UI',Arial,sans-serif;width:320px;background:#fff">&lt;table style="width:100%;border-collapse:collapse;background:#1f3b1f;color:#fff">&lt;tr>&lt;td style="width:50px;text-align:center;padding:3px">&lt;img src="file:///[% replace(replace(@project_home,'\\','/'),' ','%20') %]/ESCUDO_EJERCITO.png" width="35" height="35"/>&lt;/td>&lt;td style="text-align:center;padding:3px">&lt;div style="font-size:8.8px;letter-spacing:1.5px;color:#e8d27a;font-weight:bold">SÍMBOLOS MILITARES&lt;/div>&lt;div style="font-size:14.1px;font-weight:bold">[% coalesce(to_string("simbolo"),'-') %]&lt;/div>&lt;/td>&lt;td style="width:50px;text-align:center;padding:3px">&lt;img src="file:///[% replace(replace(@project_home,'\\','/'),' ','%20') %]/LOGO_EMTE.png" width="36" height="35"/>&lt;/td>&lt;/tr>&lt;/table>&lt;table style="width:100%;border-collapse:collapse;margin-top:3px">&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">SÍMBOLO&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("simbolo"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">BANDO / COLOR&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("bando"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">MAGNITUD DE ESCALÓN&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("escalon"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">DESIGNACIÓN (IZQUIERDA)&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("desig_izq"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">DESIGNACIÓN (DERECHA)&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("desig_der"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">TEXTO AL CENTRO&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("texto_cent"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">CALIBRE / TEXTO ABAJO&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("texto_abaj"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">PREVISTO O FUTURO (LÍNEA ENTRECORTADA)&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("previsto"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">TAMAÑO (METROS)&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("tamano"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">ROTACIÓN (°)&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("rotacion"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">OBSERVACIONES&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("obs"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">OPACIDAD&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% coalesce(to_string("opacidad"),'-') %]&lt;/td>&lt;/tr>&lt;tr>&lt;td style="background:#e9eee4;color:#1f3b1f;font-weight:bold;font-size:9.7px;padding:2px 5px;border:1px solid #c7cfbf;white-space:nowrap">COORD. (X, Y)&lt;/td>&lt;td style="font-size:10.1px;padding:2px 5px;border:1px solid #c7cfbf;color:#1b1b1b">[% format_number($x,3) %] , [% format_number($y,3) %]&lt;/td>&lt;/tr>&lt;/table>&lt;/div></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
