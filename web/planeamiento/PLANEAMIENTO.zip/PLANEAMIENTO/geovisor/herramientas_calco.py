# -*- coding: utf-8 -*-
"""Herramientas para repetir el flujo PLANEAMIENTO (calco militar + geovisor).

Se ejecuta DENTRO de QGIS (consola de Python o herramienta de código):
    exec(open(r'C:/SIG 2/PLANEAMIENTO/geovisor/herramientas_calco.py', encoding='utf-8').read())
    nuevo_proyecto('OPERACION_X', lon=-68.13, lat=-16.50)   # crea carpeta y proyecto vacío
    exportar_geovisor()                                      # exporta base.jpg + calco.png + extent.json
"""
import os, sys, glob, json, shutil, subprocess
from qgis.core import (QgsProject, QgsRectangle, QgsMapSettings, QgsMapRendererParallelJob,
                       QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY)
from qgis.PyQt.QtCore import QSize
from qgis.PyQt.QtGui import QColor
from qgis.utils import iface

PLANTILLA = 'C:/SIG 2/PLANEAMIENTO'
CAPAS = ('Símbolos militares', 'Líneas tácticas', 'Zonas y áreas')
BASE = 'Satélite Esri World Imagery (más reciente)'


def _python():
    c = [os.path.join(sys.exec_prefix, 'python.exe')] + glob.glob(os.path.join(os.path.dirname(sys.executable), '..', 'apps', 'Python*', 'python.exe'))
    c = [x for x in c if os.path.exists(x)]
    if not c:
        raise RuntimeError('No se encontró python.exe de QGIS')
    return c[0]


def nuevo_proyecto(nombre, carpeta_base='C:/SIG 2', lon=None, lat=None, plantilla=PLANTILLA):
    """Copia la plantilla a carpeta_base/nombre, vacía el calco y abre el proyecto nuevo."""
    destino = os.path.join(carpeta_base, nombre).replace('\\', '/')
    if os.path.exists(destino):
        raise RuntimeError('Ya existe la carpeta: ' + destino)
    os.makedirs(destino + '/geovisor')
    shutil.copy2(plantilla + '/PLANEAMIENTO.qgz', destino + '/' + nombre + '.qgz')
    shutil.copy2(plantilla + '/PLANEAMIENTO.gpkg', destino + '/PLANEAMIENTO.gpkg')
    shutil.copy2(plantilla + '/panel_simbolos.py', destino + '/panel_simbolos.py')
    shutil.copytree(plantilla + '/simbolos', destino + '/simbolos')
    for f in ('plantilla_geovisor.html', 'simbolos.json', 'herramientas_calco.py'):
        if os.path.exists(plantilla + '/geovisor/' + f):
            shutil.copy2(plantilla + '/geovisor/' + f, destino + '/geovisor/' + f)
    # Vaciar el calco en un proceso aparte: escribir el GeoPackage desde QGIS llegó a colgarlo.
    codigo = ("from osgeo import ogr\n"
              "ds=ogr.Open(r'%s/PLANEAMIENTO.gpkg',1)\n"
              "for n in ('simbolos_militares','lineas_tacticas','zonas_tacticas'):\n"
              "    ds.ExecuteSQL('DELETE FROM \"%%s\"' %% n)\n"
              "ds=None\nprint('ok')\n") % destino
    r = subprocess.run([_python(), '-c', codigo], capture_output=True, text=True, timeout=60, creationflags=0x08000000)
    if 'ok' not in r.stdout:
        raise RuntimeError('No se pudo vaciar el calco: ' + r.stderr[-300:])
    p = QgsProject.instance()
    p.read(destino + '/' + nombre + '.qgz')
    p.setTitle(nombre)
    if lon is not None and lat is not None:
        t = QgsCoordinateTransform(QgsCoordinateReferenceSystem('EPSG:4326'), p.crs(), p)
        c = t.transform(QgsPointXY(lon, lat))
        iface.mapCanvas().setExtent(QgsRectangle(c.x() - 6000, c.y() - 4000, c.x() + 6000, c.y() + 4000))
        iface.mapCanvas().refresh()
    p.write()
    print('Proyecto creado:', destino + '/' + nombre + '.qgz', '| capas:', len(p.mapLayers()))
    return destino


def exportar_geovisor(ancho=4800, usar_lienzo=False):
    """Exporta base.jpg y calco.png del proyecto abierto a <proyecto>/geovisor y escribe extent.json.
    El área es la de los elementos del calco (más 20 %); si el calco está vacío o usar_lienzo=True, la del lienzo."""
    p = QgsProject.instance()
    out = p.homePath() + '/geovisor'
    os.makedirs(out, exist_ok=True)
    capas = [p.mapLayersByName(n)[0] for n in CAPAS]
    ext = QgsRectangle()
    if not usar_lienzo:
        for l in capas:
            for f in l.getFeatures():
                if not f.geometry().isNull():
                    ext.combineExtentWith(f.geometry().boundingBox())
    if ext.isNull() or ext.isEmpty():
        ext = QgsRectangle(iface.mapCanvas().extent())
    else:
        ext.grow(max(ext.width(), ext.height(), 2000) * 0.2)
    W = ancho
    H = int(W * ext.height() / ext.width())
    if H > ancho:
        H = ancho
        W = int(H * ext.width() / ext.height())
    vis = None
    for nombres, archivo, fondo, fmt, q in (([BASE], 'base.jpg', QColor(40, 40, 40), 'JPG', 72),
                                            (CAPAS, 'calco.png', QColor(0, 0, 0, 0), 'PNG', -1)):
        ms = QgsMapSettings()
        ms.setLayers([p.mapLayersByName(n)[0] for n in nombres])
        ms.setDestinationCrs(p.crs()); ms.setExtent(ext); ms.setOutputSize(QSize(W, H)); ms.setBackgroundColor(fondo)
        j = QgsMapRendererParallelJob(ms); j.start(); j.waitForFinished()
        ok = j.renderedImage().save(out + '/' + archivo, fmt, q)
        vis = ms.visibleExtent()
        print(archivo, ok, os.path.getsize(out + '/' + archivo))
    datos = {'ext': [vis.xMinimum(), vis.yMinimum(), vis.xMaximum(), vis.yMaximum()], 'W': W, 'H': H,
             'elementos': {l.name(): l.featureCount() for l in capas},
             'metros_por_pixel': round(vis.width() / W, 2)}
    json.dump(datos, open(out + '/extent.json', 'w', encoding='utf-8'), ensure_ascii=False)
    print(json.dumps(datos, ensure_ascii=False))
    return datos


def exportar_figuras_json():
    """Escribe <proyecto>/geovisor/figuras_qgis.json con símbolos, líneas y zonas en el formato del geovisor
    (ids q_p_<fid>, q_l_<fid>, q_z_<fid>) para cargarlos como figuras editables."""
    p = QgsProject.instance()
    def v(f, k, d=None):
        i = f.fields().indexOf(k)
        if i < 0: return d
        x = f[k]; return d if x is None or str(x) == 'NULL' else x
    docs = {}
    for f in p.mapLayersByName('Símbolos militares')[0].getFeatures():
        q = f.geometry().asPoint()
        docs['q_p_%d' % f.id()] = {'key': v(f, 'simbolo', 'unidad'), 'bando': v(f, 'bando', 'Propio'), 'x': round(q.x(), 1), 'y': round(q.y(), 1),
            'tam': float(v(f, 'tamano', 600)), 'rot': float(v(f, 'rotacion', 0)), 'esc': v(f, 'escalon', ''), 'izq': v(f, 'desig_izq', ''),
            'der': v(f, 'desig_der', ''), 'cen': v(f, 'texto_centro', ''), 'aba': v(f, 'texto_abajo', ''), 'prev': int(v(f, 'previsto', 0) or 0), 'op': int(v(f, 'opacidad', 100))}
    for n, k in (('Líneas tácticas', 'l'), ('Zonas y áreas', 'z')):
        for f in p.mapLayersByName(n)[0].getFeatures():
            g = f.geometry(); pts = []
            if k == 'l':
                for parte in (g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]): pts += parte
            else:
                for parte in (g.asMultiPolygon() if g.isMultipart() else [g.asPolygon()]): pts += parte[0][:-1]
            lim = []
            for q in pts:
                if not lim or q.distance(lim[-1]) > 0.01: lim.append(q)
            docs['q_%s_%d' % (k, f.id())] = {'k': k, 'tipo': v(f, 'tipo', ''), 'bando': v(f, 'bando', 'Propio'), 'et': v(f, 'etiqueta', ''),
                'fh': v(f, 'fecha_hora', ''), 'op': int(v(f, 'opacidad', 100)), 'p': [c for q in lim for c in (round(q.x(), 1), round(q.y(), 1))]}
    ruta = p.homePath() + '/geovisor/figuras_qgis.json'
    json.dump(docs, open(ruta, 'w', encoding='utf-8'), ensure_ascii=False)
    print(len(docs), 'figuras ->', ruta)
    return docs
