# -*- coding: utf-8 -*-
# Panel «Simbología militar» del proyecto PLANEAMIENTO (versión 2: ajuste tipo imagen + ficha)
import os, json, math, re, sys, glob, subprocess, datetime, csv, shutil, zipfile
from qgis.core import (QgsPrintLayout, QgsLayoutItemPage, QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes, QgsLayoutItemLabel, QgsTextFormat,
                       QgsLayoutItemMap, QgsLayoutItemMapGrid, QgsLineSymbol, QgsLayoutItemScaleBar, QgsScaleBarSettings, QgsLayoutItemPicture,
                       QgsSymbolLayerUtils, QgsPathResolver, QgsLayoutExporter, Qgis, QgsProject, QgsFeature, QgsGeometry, QgsPointXY, QgsRectangle, QgsWkbTypes,
                       QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsDefaultValue)
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint, QgsRubberBand, QgsVertexMarker
from qgis.utils import iface
import qgis.utils as _qu
from qgis.PyQt.QtCore import Qt, QMimeData, QObject, QEvent, QSize, QTimer, QUrl
from qgis.PyQt.QtGui import QIcon, QColor, QTransform, QGuiApplication, QFont, QDesktopServices, QPen, QBrush
from qgis.PyQt.QtWidgets import (QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QTreeWidget, QTreeWidgetItem,
    QLineEdit, QComboBox, QCheckBox, QDoubleSpinBox, QSpinBox, QSlider, QPushButton, QLabel, QAbstractItemView, QTabWidget,
    QTableWidget, QTableWidgetItem, QHeaderView, QScrollArea, QFrame, QGroupBox, QGraphicsSimpleTextItem, QGraphicsRectItem)

MIME = 'application/x-simbolo-militar'
N_PTS, N_LIN, N_ZON = 'Símbolos militares', 'Líneas tácticas', 'Zonas y áreas'
BASES = ('Satélite Esri World Imagery (más reciente)', 'Satélite Google (alternativa)')
BANDOS = [('Propio (azul)', 'Propio'), ('Enemigo (rojo)', 'Enemigo'), ('Obstáculo (verde)', 'Obstáculo'), ('Contaminado (amarillo)', 'Contaminado'), ('Obras y poblaciones (negro)', 'Negro')]
ESC = [('(sin escalón)', ''), ('XXXXXX  Cmdo. Gral. del Ejército', 'XXXXXX'), ('XXXXX  Cmdo. del TO / ZI', 'XXXXX'), ('XXXX  Cmdo. FF.TT. del TO', 'XXXX'), ('XXX  Cuerpo de Ejército', 'XXX'), ('XX  División', 'XX'), ('X  Brigada', 'X'), ('III  Regimiento', 'III'), ('II  Batallón / Grupo', 'II'), ('I  Compañía / Escuadrón / Batería', 'I'), ('●●  Sección', '●●'), ('●  Escuadra', '●'), ('▲  Equipo', '▲')]
AMARILLO = QColor(255, 200, 0)
WGS = QgsCoordinateReferenceSystem('EPSG:4326')


def _capa(nombre):
    l = QgsProject.instance().mapLayersByName(nombre)
    return l[0] if l else None


def _guardar(capa):
    """Guarda en el archivo los cambios de la capa sin salir del modo edición."""
    if capa is not None and capa.isEditable() and capa.isModified():
        if not capa.commitChanges(False):
            iface.messageBar().pushMessage('Simbología', 'No se pudo guardar «%s»: %s' % (capa.name(), '; '.join(capa.commitErrors())), Qgis.Warning, 10)
            return False
    return True


def _rot(dx, dy, grados):
    """Gira un desplazamiento (x, y con y hacia arriba) en sentido horario."""
    a = math.radians(grados)
    return dx * math.cos(a) + dy * math.sin(a), -dx * math.sin(a) + dy * math.cos(a)


def _gms(v, pos, neg):
    h = pos if v >= 0 else neg
    v = abs(v); d = int(v); m = int((v - d) * 60); s = (v - d - m / 60) * 3600
    if s >= 59.95: s = 0; m += 1
    if m == 60: m = 0; d += 1
    return "%d°%02d'%04.1f\" %s" % (d, m, s, h)


class Arbol(QTreeWidget):
    def mimeTypes(self):
        return [MIME]

    def mimeData(self, items):
        md = QMimeData()
        if items and items[0].data(0, Qt.UserRole):
            md.setData(MIME, json.dumps(items[0].data(0, Qt.UserRole)).encode('utf-8'))
        return md


class Filtro(QObject):
    def __init__(self, panel):
        super().__init__(panel); self.p = panel

    def eventFilter(self, obj, ev):
        t = ev.type()
        # Como en ATAK: un toque sobre un elemento lo selecciona y abre su ficha, aunque se esté usando la mano (desplazar).
        if obj is iface.mapCanvas().viewport() and t in (QEvent.MouseButtonPress, QEvent.MouseButtonRelease) and ev.button() == Qt.LeftButton:
            herr = iface.mapCanvas().mapTool()
            if herr is not None and herr is not self.p.ajustar and herr.__class__.__name__ in ('QgsMapToolPan', 'QgsMapToolZoom', 'QgsMapToolIdentifyAction', 'QgsMapToolSelect'):
                if t == QEvent.MouseButtonPress:
                    self._ini = ev.pos()
                elif getattr(self, '_ini', None) is not None and (ev.pos() - self._ini).manhattanLength() < 5:
                    pos = ev.pos(); self._ini = None
                    QTimer.singleShot(0, lambda pos=pos: self.p.tocar(pos))
            return False
        if t in (QEvent.DragEnter, QEvent.DragMove) and ev.mimeData().hasFormat(MIME):
            ev.setDropAction(Qt.CopyAction); ev.accept(); return True
        if t == QEvent.Drop and ev.mimeData().hasFormat(MIME):
            d = json.loads(bytes(ev.mimeData().data(MIME)).decode('utf-8'))
            pos = ev.pos()
            pt = iface.mapCanvas().getCoordinateTransform().toMapCoordinates(pos.x(), pos.y())
            ev.setDropAction(Qt.CopyAction); ev.accept(); self.p.soltar(d, pt); return True
        return False


class Ajustar(QgsMapTool):
    """Selecciona y ajusta elementos como imágenes: arrastrar = mover, esquinas = tamaño, círculo = girar."""

    def __init__(self, panel):
        super().__init__(iface.mapCanvas())
        self.p = panel; self.modo = None; self.ini = None; self.prev = None
        cv = self.canvas()
        self.marco = QgsRubberBand(cv, QgsWkbTypes.PolygonGeometry)
        self.marco.setStrokeColor(AMARILLO); self.marco.setFillColor(QColor(0, 0, 0, 0)); self.marco.setWidth(2); self.marco.setLineStyle(Qt.DashLine)
        self.forma = QgsRubberBand(cv, QgsWkbTypes.LineGeometry)
        self.forma.setStrokeColor(QColor(255, 200, 0, 200)); self.forma.setWidth(2)
        self.esq = []
        for _ in range(4):
            m = QgsVertexMarker(cv); m.setIconType(QgsVertexMarker.ICON_BOX); m.setIconSize(14); m.setPenWidth(3); m.setColor(AMARILLO); m.setFillColor(AMARILLO); self.esq.append(m)
        self.giro = QgsVertexMarker(cv); self.giro.setIconType(QgsVertexMarker.ICON_CIRCLE); self.giro.setIconSize(16); self.giro.setPenWidth(3); self.giro.setColor(AMARILLO)
        self.rotulos = []
        self.setCursor(Qt.OpenHandCursor); self.ocultar()

    # ---------- marco ----------
    def ocultar(self):
        self.marco.reset(QgsWkbTypes.PolygonGeometry); self.forma.reset(QgsWkbTypes.LineGeometry)
        for m in self.esq + [self.giro]: m.hide()
        self.quitar_rotulos()

    def quitar_rotulos(self):
        esc = self.canvas().scene()
        for it in getattr(self, 'rotulos', []):
            try: esc.removeItem(it)
            except Exception: pass
        self.rotulos = []

    def poner_rotulos(self, capa, f):
        # rótulos P1, P2… (líneas) o V1, V2… (zonas) y «Centro», para identificar las filas de la ficha
        self.quitar_rotulos()
        if capa.name() == N_PTS: return
        esc = self.canvas().scene(); fnt = QFont('Arial', 9); fnt.setBold(True)
        for nombre, q in self.p.puntos(capa, f):
            c = self.toCanvasCoordinates(q)
            t = QGraphicsSimpleTextItem(nombre); t.setFont(fnt); t.setBrush(QColor(20, 20, 10))
            br = t.boundingRect()
            fondo = QGraphicsRectItem(0, 0, br.width() + 6, br.height() + 2); fondo.setBrush(QBrush(AMARILLO)); fondo.setPen(QPen(QColor(20, 20, 10)))
            fondo.setPos(c.x() + 9, c.y() - br.height() - 8); t.setParentItem(fondo); t.setPos(3, 1)
            fondo.setZValue(1000); esc.addItem(fondo); self.rotulos.append(fondo)

    def datos_marco(self, capa, f, ajuste=None):
        """Centro, 4 esquinas y punto de giro del elemento (con un ajuste en curso opcional)."""
        u = self.canvas().mapUnitsPerPixel()
        if capa.name() == N_PTS:
            c = f.geometry().asPoint(); lado = float(f['tamano'] or 600); rot = float(f['rotacion'] or 0)
            if ajuste:
                if ajuste[0] == 'mover': c = QgsPointXY(c.x() + ajuste[1], c.y() + ajuste[2])
                elif ajuste[0] == 'tam': lado = ajuste[1]
                elif ajuste[0] == 'giro': rot = ajuste[1]
            h = max(lado / 2, 12 * u)
            esq = [QgsPointXY(c.x() + a, c.y() + b) for a, b in (_rot(-h, h, rot), _rot(h, h, rot), _rot(h, -h, rot), _rot(-h, -h, rot))]
            gx, gy = _rot(0, h + 28 * u, rot)
            return c, esq, QgsPointXY(c.x() + gx, c.y() + gy), None
        g = self.geom_ajustada(f.geometry(), ajuste)
        bb = g.boundingBox(); c = bb.center()
        if bb.width() < 24 * u: bb.grow((24 * u - bb.width()) / 2)
        esq = [QgsPointXY(bb.xMinimum(), bb.yMaximum()), QgsPointXY(bb.xMaximum(), bb.yMaximum()), QgsPointXY(bb.xMaximum(), bb.yMinimum()), QgsPointXY(bb.xMinimum(), bb.yMinimum())]
        return c, esq, QgsPointXY(c.x(), bb.yMaximum() + 28 * u), g

    def geom_ajustada(self, g0, ajuste):
        g = QgsGeometry(g0)
        if not ajuste: return g
        c = g0.boundingBox().center()
        if ajuste[0] == 'mover': g.translate(ajuste[1], ajuste[2])
        elif ajuste[0] == 'escala':
            k = ajuste[1]; g.transform(QTransform(k, 0, 0, k, c.x() - k * c.x(), c.y() - k * c.y()))
        elif ajuste[0] == 'rotar': g.rotate(ajuste[1], c)
        return g

    def dibujar(self, ajuste=None):
        capa, f = self.p.elemento()
        if f is None: self.ocultar(); return
        c, esq, gp, g = self.datos_marco(capa, f, ajuste)
        self.marco.setToGeometry(QgsGeometry.fromPolygonXY([esq + [esq[0]]]), None)
        for m, q in zip(self.esq, esq): m.setCenter(q); m.show()
        self.giro.setCenter(gp); self.giro.show()
        if g is not None: self.forma.setToGeometry(g, None)
        else: self.forma.reset(QgsWkbTypes.LineGeometry)
        if ajuste: self.quitar_rotulos()
        else: self.poner_rotulos(capa, f)

    # ---------- elegir ----------
    def elegir(self, pt):
        u = self.canvas().mapUnitsPerPixel(); tol = 14 * u
        l = _capa(N_PTS)
        if l:
            mejor = None
            for f in l.getFeatures(QgsRectangle(pt.x() - 50000, pt.y() - 50000, pt.x() + 50000, pt.y() + 50000)):
                q = f.geometry().asPoint(); d = math.hypot(q.x() - pt.x(), q.y() - pt.y())
                if d <= max(float(f['tamano'] or 600) * 0.5, tol) and (mejor is None or d < mejor[0]): mejor = (d, f.id())
            if mejor: return l, mejor[1]
        gp = QgsGeometry.fromPointXY(pt)
        for nombre in (N_LIN, N_ZON):
            l = _capa(nombre)
            if not l: continue
            mejor = None
            for f in l.getFeatures(QgsRectangle(pt.x() - tol, pt.y() - tol, pt.x() + tol, pt.y() + tol)):
                d = f.geometry().distance(gp)
                if d <= tol and (mejor is None or d < mejor[0]): mejor = (d, f.id())
            if mejor: return l, mejor[1]
        return None, None

    # ---------- ratón ----------
    def canvasPressEvent(self, e):
        if e.button() != Qt.LeftButton: return
        pt = e.mapPoint(); self.ini = pt; self.prev = None; self.modo = None
        capa, f = self.p.elemento()
        if f is not None:
            c, esq, gp, g = self.datos_marco(capa, f)
            px = lambda q: self.toCanvasCoordinates(q)
            ep = e.pos()
            if (px(gp) - ep).manhattanLength() <= 14: self.modo = 'giro'
            elif any((px(q) - ep).manhattanLength() <= 14 for q in esq): self.modo = 'tam'
            elif QgsGeometry.fromPolygonXY([esq + [esq[0]]]).contains(QgsGeometry.fromPointXY(pt)): self.modo = 'mover'
            if self.modo:
                self.c0 = c; self.setCursor(Qt.ClosedHandCursor); return
        capa, fid = self.elegir(pt)
        self.p.seleccionar(capa, fid)
        if fid is not None:
            capa, f = self.p.elemento(); self.c0 = self.datos_marco(capa, f)[0]; self.modo = 'mover'; self.setCursor(Qt.ClosedHandCursor)

    def ajuste_actual(self, pt):
        capa, f = self.p.elemento()
        if f is None or self.modo is None: return None
        pts = capa.name() == N_PTS; c = self.c0
        if self.modo == 'mover': return ('mover', pt.x() - self.ini.x(), pt.y() - self.ini.y())
        if self.modo == 'tam':
            if pts: return ('tam', max(5.0, math.hypot(pt.x() - c.x(), pt.y() - c.y()) * math.sqrt(2)))
            d0 = math.hypot(self.ini.x() - c.x(), self.ini.y() - c.y()) or 1
            return ('escala', max(0.05, math.hypot(pt.x() - c.x(), pt.y() - c.y()) / d0))
        ang = math.degrees(math.atan2(pt.x() - c.x(), pt.y() - c.y()))
        if pts: return ('giro', round(ang % 360))
        a0 = math.degrees(math.atan2(self.ini.x() - c.x(), self.ini.y() - c.y()))
        return ('rotar', ang - a0)

    def canvasMoveEvent(self, e):
        if self.modo is None or self.ini is None: return
        if (self.toCanvasCoordinates(self.ini) - e.pos()).manhattanLength() < 3: return
        self.prev = self.ajuste_actual(e.mapPoint()); self.dibujar(self.prev)

    def canvasReleaseEvent(self, e):
        self.setCursor(Qt.OpenHandCursor)
        aj = self.prev; self.modo = None; self.ini = None; self.prev = None
        if aj: self.p.aplicar_ajuste(aj)
        else: self.dibujar()

    def wheelEvent(self, e):
        if self.p.elemento()[1] is not None and (e.modifiers() & Qt.ControlModifier):
            self.p.escalar(1.1 if e.angleDelta().y() > 0 else 1 / 1.1); e.accept()
        else: e.ignore()

    def keyPressEvent(self, e):
        k = e.key()
        if k in (Qt.Key_Plus, Qt.Key_Equal): self.p.escalar(1.1)
        elif k == Qt.Key_Minus: self.p.escalar(1 / 1.1)
        elif k == Qt.Key_Delete: self.p.borrar()
        elif k == Qt.Key_Escape: self.p.seleccionar(None, None)
        else: e.ignore()

    def deactivate(self):
        self.ocultar(); super().deactivate()

    def activate(self):
        super().activate(); self.dibujar()


class Panel(QDockWidget):
    def __init__(self):
        super().__init__('Simbología militar', iface.mainWindow())
        self.setObjectName('PanelSimbologiaMilitar')
        self.home = QgsProject.instance().homePath()
        self.sel = (None, None); self._pend = None; self._carga = False; self._con = []
        d = os.path.join(self.home, 'simbolos')
        self.cat = json.load(open(os.path.join(d, 'catalogo.json'), encoding='utf-8'))
        self.tipos = json.load(open(os.path.join(d, 'tipos.json'), encoding='utf-8'))
        self.nombre = {c['key']: c['nombre'] for c in self.cat}
        self.tabs = QTabWidget(); self.setWidget(self.tabs)
        self.tabs.addTab(self.hacer_catalogo(), 'Catálogo')
        self.tabs.addTab(self.hacer_ficha(), 'Ficha')
        self.ajustar = Ajustar(self)
        self.punto = QgsMapToolEmitPoint(iface.mapCanvas()); self.punto.canvasClicked.connect(self._clic)
        self.filtro = Filtro(self)
        cv = iface.mapCanvas(); cv.viewport().installEventFilter(self.filtro); cv.installEventFilter(self.filtro)
        self._conectar(cv.extentsChanged, self.redibujar)
        for n in (N_PTS, N_LIN, N_ZON):
            l = _capa(n)
            if l:
                self._conectar(l.selectionChanged, lambda *a, n=n: self.sel_externa(n))
                self._conectar(l.featureAdded, lambda fid, n=n: QTimer.singleShot(0, lambda: self.nuevo_dibujo(n, fid)))
        self.cargar_ficha()

    def _conectar(self, señal, f):
        señal.connect(f); self._con.append((señal, f))

    # ---------- pestaña Catálogo ----------
    def hacer_catalogo(self):
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(6, 6, 6, 6)
        self.buscar = QLineEdit(); self.buscar.setPlaceholderText('Buscar símbolo, línea o zona…'); self.buscar.setClearButtonEnabled(True)
        self.buscar.textChanged.connect(self.filtrar); v.addWidget(self.buscar)
        self.tree = Arbol(); self.tree.setHeaderHidden(True); self.tree.setIconSize(QSize(40, 40))
        self.tree.setDragEnabled(True); self.tree.setDragDropMode(QAbstractItemView.DragOnly)
        self.tree.itemDoubleClicked.connect(self.doble); v.addWidget(self.tree, 1)
        self.poblar()
        fl = QFormLayout()
        self.cb_bando_n = QComboBox(); [self.cb_bando_n.addItem(a, b) for a, b in BANDOS]
        fl.addRow('Bando al colocar', self.cb_bando_n); v.addLayout(fl)
        self.ck_auto = QCheckBox('Tamaño automático según la escala'); self.ck_auto.setChecked(True); v.addWidget(self.ck_auto)
        self.ck_guardar = QCheckBox('Guardar en el archivo después de cada cambio'); self.ck_guardar.setChecked(True); v.addWidget(self.ck_guardar)
        gb = QGroupBox('Opacidad de las capas'); gl = QFormLayout(gb)
        for nombre, etiqueta in ((BASES[0], 'Imagen Esri'), (BASES[1], 'Imagen Google'), (N_PTS, 'Símbolos'), (N_LIN, 'Líneas'), (N_ZON, 'Zonas')):
            l = _capa(nombre)
            if not l: continue
            s = QSlider(Qt.Horizontal); s.setRange(0, 100); s.setValue(int(round(l.opacity() * 100)))
            s.valueChanged.connect(lambda val, nombre=nombre: self.opacidad_capa(nombre, val)); gl.addRow(etiqueta, s)
        v.addWidget(gb)
        ge = QGroupBox('Guardar shape y carta (carpetas SHAPES y CARTAS)'); ef = QFormLayout(ge)
        self.e_nombre = QLineEdit('Calco ' + datetime.date.today().strftime('%d-%m-%Y'))
        self.e_area = QComboBox(); self.e_area.addItems(['Lo que se ve en pantalla', 'Todas las figuras'])
        ef.addRow('Nombre', self.e_nombre); ef.addRow('Área de la carta', self.e_area)
        eh = QHBoxLayout()
        b_s = QPushButton('Guardar shape'); b_s.clicked.connect(self.exportar_shape)
        b_c = QPushButton('Guardar carta'); b_c.clicked.connect(self.exportar_carta)
        b_a = QPushButton('Abrir SHAPES'); b_a.clicked.connect(self.abrir_carpeta)
        eh.addWidget(b_s); eh.addWidget(b_c); eh.addWidget(b_a); ef.addRow(eh)
        self.e_estado = QLabel(''); self.e_estado.setWordWrap(True); self.e_estado.setStyleSheet('color:#555;font-size:8pt'); ef.addRow(self.e_estado)
        v.addWidget(ge)
        hb = QHBoxLayout()
        b1 = QPushButton('Seleccionar y ajustar'); b1.clicked.connect(self.activar_ajuste)
        b2 = QPushButton('Guardar cambios'); b2.clicked.connect(self.guardar)
        hb.addWidget(b1); hb.addWidget(b2); v.addLayout(hb)
        ay = QLabel('Arrastra un símbolo al mapa (o doble clic y clic en el mapa). Luego, como una imagen: arrastra para mover, '
                    'tira de las esquinas para cambiar el tamaño y del círculo para girar. Líneas y zonas: doble clic y dibuja; clic derecho termina.')
        ay.setWordWrap(True); ay.setStyleSheet('color:#555;font-size:8pt'); v.addWidget(ay)
        return w

    def poblar(self):
        d = os.path.join(self.home, 'simbolos'); nd = Qt.ItemIsEnabled
        r1 = QTreeWidgetItem(self.tree, ['SÍMBOLOS (unidades, puestos, puntos)']); r1.setFlags(nd)
        grupos = {}
        for c in self.cat:
            g = grupos.get(c['cat'])
            if g is None: g = QTreeWidgetItem(r1, [c['cat']]); g.setFlags(nd); grupos[c['cat']] = g
            it = QTreeWidgetItem(g, [c['nombre']]); it.setIcon(0, QIcon(os.path.join(d, c['key'] + '.svg')))
            it.setData(0, Qt.UserRole, {'k': 'p', 'key': c['key'], 'bando': c['bando']})
        for titulo, k, lista in (('LÍNEAS TÁCTICAS', 'l', self.tipos['lineas']), ('ZONAS Y ÁREAS', 'z', self.tipos['zonas'])):
            r = QTreeWidgetItem(self.tree, [titulo]); r.setFlags(nd)
            for t in lista:
                it = QTreeWidgetItem(r, [t]); it.setData(0, Qt.UserRole, {'k': k, 'tipo': t})
        r1.setExpanded(True)

    def filtrar(self, txt):
        txt = txt.strip().lower()
        def rec(it):
            if it.childCount() == 0:
                vis = (txt in it.text(0).lower()) if txt else True; it.setHidden(not vis); return vis
            alguno = False
            for i in range(it.childCount()): alguno = rec(it.child(i)) or alguno
            it.setHidden(not alguno)
            if txt: it.setExpanded(True)
            return alguno
        for i in range(self.tree.topLevelItemCount()): rec(self.tree.topLevelItem(i))

    def opacidad_capa(self, nombre, val):
        l = _capa(nombre)
        if l: l.setOpacity(val / 100.0); l.triggerRepaint(); QgsProject.instance().setDirty(True)

    # ---------- pestaña Ficha ----------
    def hacer_ficha(self):
        sc = QScrollArea(); sc.setWidgetResizable(True); sc.setFrameShape(QFrame.NoFrame)
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(6, 6, 6, 6); sc.setWidget(w)
        self.f_titulo = QLabel('Ningún elemento seleccionado'); self.f_titulo.setWordWrap(True)
        self.f_titulo.setStyleSheet('font-weight:bold;font-size:11pt'); v.addWidget(self.f_titulo)
        self.f_sub = QLabel('Pulsa «Seleccionar y ajustar» y haz clic en un símbolo, línea o zona.'); self.f_sub.setWordWrap(True); self.f_sub.setStyleSheet('color:#555'); v.addWidget(self.f_sub)
        # campos de símbolo
        self.g_sim = QWidget(); fs = QFormLayout(self.g_sim); fs.setContentsMargins(0, 0, 0, 0)
        self.f_simbolo = QComboBox(); [self.f_simbolo.addItem(QIcon(os.path.join(self.home, 'simbolos', c['key'] + '.svg')), c['nombre'], c['key']) for c in self.cat]
        self.f_esc = QComboBox(); [self.f_esc.addItem(a, b) for a, b in ESC]
        self.f_izq = QLineEdit(); self.f_der = QLineEdit(); self.f_cen = QLineEdit(); self.f_aba = QLineEdit()
        self.f_prev = QCheckBox('Previsto / futuro (línea entrecortada)')
        self.f_tam = QDoubleSpinBox(); self.f_tam.setRange(5, 500000); self.f_tam.setDecimals(0); self.f_tam.setSingleStep(50); self.f_tam.setSuffix(' m')
        self.f_rot = QDoubleSpinBox(); self.f_rot.setRange(0, 359); self.f_rot.setDecimals(0); self.f_rot.setWrapping(True); self.f_rot.setSuffix(' °')
        fs.addRow('Símbolo', self.f_simbolo); fs.addRow('Escalón', self.f_esc)
        fs.addRow('Desig. izquierda', self.f_izq); fs.addRow('Desig. derecha', self.f_der)
        fs.addRow('Texto al centro', self.f_cen); fs.addRow('Calibre / abajo', self.f_aba)
        fs.addRow('Tamaño', self.f_tam); fs.addRow('Rotación', self.f_rot); fs.addRow('', self.f_prev)
        v.addWidget(self.g_sim)
        # campos de línea / zona
        self.g_vec = QWidget(); fv = QFormLayout(self.g_vec); fv.setContentsMargins(0, 0, 0, 0)
        self.f_tipo = QComboBox(); self.f_et = QLineEdit(); self.f_fh = QLineEdit(); self.f_fh.setPlaceholderText('160500-MAR-26')
        fv.addRow('Tipo', self.f_tipo); fv.addRow('Nombre / número', self.f_et); fv.addRow('Fecha-hora', self.f_fh)
        v.addWidget(self.g_vec)
        # comunes
        fc = QFormLayout()
        self.f_bando = QComboBox(); [self.f_bando.addItem(a, b) for a, b in BANDOS]
        self.f_op = QSlider(Qt.Horizontal); self.f_op.setRange(0, 100)
        self.f_opn = QSpinBox(); self.f_opn.setRange(0, 100); self.f_opn.setSuffix(' %')
        ho = QHBoxLayout(); ho.addWidget(self.f_op, 1); ho.addWidget(self.f_opn)
        fc.addRow('Bando / color', self.f_bando); fc.addRow('Opacidad', ho)
        self.g_com = QWidget(); self.g_com.setLayout(fc); v.addWidget(self.g_com)
        hb = QHBoxLayout()
        b_men = QPushButton('− Achicar'); b_mas = QPushButton('+ Agrandar')
        b_men.clicked.connect(lambda: self.escalar(1 / 1.15)); b_mas.clicked.connect(lambda: self.escalar(1.15))
        hb.addWidget(b_men); hb.addWidget(b_mas); self.g_esc = QWidget(); self.g_esc.setLayout(hb); v.addWidget(self.g_esc)
        # coordenadas
        hc = QHBoxLayout(); lc = QLabel('Coordenadas (WGS 84)'); lc.setStyleSheet('font-weight:bold')
        self.f_fmt = QComboBox(); self.f_fmt.addItems(['Grados decimales', 'Grados, minutos, segundos'])
        hc.addWidget(lc, 1); hc.addWidget(self.f_fmt); v.addLayout(hc)
        self.f_tab = QTableWidget(0, 5); self.f_tab.setHorizontalHeaderLabels(['Punto', 'Latitud', 'Longitud', 'UTM Este', 'UTM Norte'])
        self.f_tab.verticalHeader().setVisible(False); self.f_tab.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.f_tab.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.f_tab.setMinimumHeight(150)
        v.addWidget(self.f_tab, 1)
        self.f_zona = QLabel(''); self.f_zona.setStyleSheet('color:#555;font-size:8pt'); v.addWidget(self.f_zona)
        hb2 = QHBoxLayout()
        b_cp = QPushButton('Copiar coordenadas'); b_cp.clicked.connect(self.copiar)
        b_ce = QPushButton('Centrar mapa'); b_ce.clicked.connect(self.centrar)
        b_del = QPushButton('Eliminar'); b_del.setStyleSheet('color:#b00'); b_del.clicked.connect(self.borrar)
        hb2.addWidget(b_cp); hb2.addWidget(b_ce); hb2.addWidget(b_del); v.addLayout(hb2)
        # señales
        self.f_simbolo.currentIndexChanged.connect(lambda i: self.cambiar('simbolo', self.f_simbolo.currentData()))
        self.f_esc.currentIndexChanged.connect(lambda i: self.cambiar('escalon', self.f_esc.currentData()))
        for campo, ed in (('desig_izq', self.f_izq), ('desig_der', self.f_der), ('texto_centro', self.f_cen), ('texto_abajo', self.f_aba), ('etiqueta', self.f_et), ('fecha_hora', self.f_fh)):
            ed.editingFinished.connect(lambda campo=campo, ed=ed: self.cambiar(campo, ed.text().strip()))
        self.f_prev.toggled.connect(lambda c: self.cambiar('previsto', 1 if c else 0))
        self.f_tam.editingFinished.connect(lambda: self.cambiar('tamano', float(self.f_tam.value())))
        self.f_rot.editingFinished.connect(lambda: self.cambiar('rotacion', float(self.f_rot.value())))
        self.f_tipo.currentIndexChanged.connect(lambda i: self.cambiar('tipo', self.f_tipo.currentText()))
        self.f_bando.currentIndexChanged.connect(lambda i: self.cambiar('bando', self.f_bando.currentData()))
        self.f_op.valueChanged.connect(self._op_slider); self.f_op.sliderReleased.connect(lambda: self.cambiar('opacidad', self.f_op.value()))
        self.f_opn.editingFinished.connect(lambda: (self.f_op.setValue(self.f_opn.value()), self.cambiar('opacidad', self.f_opn.value())))
        self.f_fmt.currentIndexChanged.connect(lambda i: self.cargar_ficha())
        return sc

    def _op_slider(self, val):
        self.f_opn.blockSignals(True); self.f_opn.setValue(val); self.f_opn.blockSignals(False)
        if not self._carga and not self.f_op.isSliderDown(): self.cambiar('opacidad', val)

    # ---------- selección ----------
    def elemento(self):
        capa, fid = self.sel
        if capa is None or fid is None: return None, None
        try:
            f = capa.getFeature(fid)
        except RuntimeError:
            self.sel = (None, None); return None, None
        if not f.isValid() or f.geometry().isNull(): return None, None
        return capa, f

    def seleccionar(self, capa, fid):
        self.sel = (capa, fid)
        self._carga = True
        try:
            for n in (N_PTS, N_LIN, N_ZON):
                l = _capa(n)
                if l is None: continue
                if l is capa and fid is not None: l.selectByIds([fid])
                elif l.selectedFeatureCount(): l.removeSelection()
        finally:
            self._carga = False
        self.cargar_ficha(); self.redibujar()
        if fid is not None: self.tabs.setCurrentIndex(1)

    def sel_externa(self, nombre):
        if self._carga: return
        l = _capa(nombre)
        if l is not None and l.selectedFeatureCount() == 1:
            self.sel = (l, l.selectedFeatureIds()[0]); self.cargar_ficha(); self.redibujar()

    def redibujar(self, *a):
        if iface.mapCanvas().mapTool() is self.ajustar: self.ajustar.dibujar()

    def cargar_ficha(self):
        capa, f = self.elemento()
        self._carga = True
        try:
            hay = f is not None
            for g in (self.g_com, self.g_esc): g.setVisible(hay)
            self.g_sim.setVisible(hay and capa.name() == N_PTS); self.g_vec.setVisible(hay and capa.name() != N_PTS)
            self.f_tab.setRowCount(0); self.f_zona.setText('')
            if not hay:
                self.f_titulo.setText('Ningún elemento seleccionado')
                self.f_sub.setText('Pulsa «Seleccionar y ajustar» y haz clic en un símbolo, línea o zona.'); return
            op = f['opacidad'] if f.fields().indexOf('opacidad') >= 0 else None
            op = 100 if op in (None, '') or str(op) == 'NULL' else int(op)
            self.f_op.setValue(op); self.f_opn.setValue(op)
            self.f_bando.setCurrentIndex(max(0, self.f_bando.findData(f['bando'] or 'Propio')))
            if capa.name() == N_PTS:
                self.f_titulo.setText(self.nombre.get(f['simbolo'], f['simbolo'] or 'Símbolo'))
                self.f_sub.setText('Símbolo militar · n.º %d' % f.id())
                self.f_simbolo.setCurrentIndex(max(0, self.f_simbolo.findData(f['simbolo'])))
                self.f_esc.setCurrentIndex(max(0, self.f_esc.findData(f['escalon'] or '')))
                for ed, campo in ((self.f_izq, 'desig_izq'), (self.f_der, 'desig_der'), (self.f_cen, 'texto_centro'), (self.f_aba, 'texto_abajo')):
                    val = f[campo]; ed.setText('' if val in (None,) or str(val) == 'NULL' else str(val))
                self.f_prev.setChecked(bool(f['previsto'])); self.f_tam.setValue(float(f['tamano'] or 600)); self.f_rot.setValue(float(f['rotacion'] or 0) % 360)
            else:
                lista = self.tipos['lineas' if capa.name() == N_LIN else 'zonas']
                self.f_tipo.clear(); self.f_tipo.addItems(lista)
                i = self.f_tipo.findText(f['tipo'] or '')
                if i < 0 and f['tipo']: self.f_tipo.addItem(f['tipo']); i = self.f_tipo.count() - 1
                self.f_tipo.setCurrentIndex(max(0, i))
                self.f_titulo.setText(f['tipo'] or capa.name())
                g = f.geometry()
                medida = ('Longitud: %.2f km' % (g.length() / 1000 * self._factor(g))) if capa.name() == N_LIN else ('Superficie: %.2f km²' % (g.area() / 1e6 * self._factor(g) ** 2))
                self.f_sub.setText('%s · n.º %d · %s' % ('Línea táctica' if capa.name() == N_LIN else 'Zona', f.id(), medida))
                for ed, campo in ((self.f_et, 'etiqueta'), (self.f_fh, 'fecha_hora')):
                    val = f[campo]; ed.setText('' if val is None or str(val) == 'NULL' else str(val))
            self.llenar_coordenadas(capa, f)
        finally:
            self._carga = False

    def _factor(self, g):
        """Corrección aproximada de Web Mercator a metros reales en la latitud del elemento."""
        if QgsProject.instance().crs().authid() != 'EPSG:3857': return 1.0
        y = g.boundingBox().center().y()
        lat = math.degrees(2 * math.atan(math.exp(y / 6378137.0)) - math.pi / 2)
        return math.cos(math.radians(lat))

    def puntos(self, capa, f):
        g = f.geometry()
        if capa.name() == N_PTS: return [('Centro', g.asPoint())]
        if capa.name() == N_ZON:
            vs = []
            for parte in (g.asMultiPolygon() if g.isMultipart() else [g.asPolygon()]):
                if parte: vs += parte[0][:-1]
            filas = [('V%d' % (i + 1), q) for i, q in enumerate(vs)]
        else:
            vs = []
            for parte in (g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]): vs += parte
            filas = [('P%d' % (i + 1), q) for i, q in enumerate(vs)]
        limpio = []
        for _, q in filas:
            if not limpio or q.distance(limpio[-1]) > 0.01: limpio.append(q)
        letra = 'V' if capa.name() == N_ZON else 'P'
        filas = [('%s%d' % (letra, i + 1), q) for i, q in enumerate(limpio)]
        c = g.centroid().asPoint() if capa.name() == N_ZON else g.interpolate(g.length() / 2).asPoint()
        return filas + [('Centro', c)]

    def llenar_coordenadas(self, capa, f):
        filas = self.puntos(capa, f)
        a_wgs = QgsCoordinateTransform(capa.crs(), WGS, QgsProject.instance())
        c = a_wgs.transform(f.geometry().boundingBox().center())
        zona = int((c.x() + 180) // 6) + 1
        utm = QgsCoordinateReferenceSystem('EPSG:%d' % ((32700 if c.y() < 0 else 32600) + zona))
        a_utm = QgsCoordinateTransform(capa.crs(), utm, QgsProject.instance())
        gms = self.f_fmt.currentIndex() == 1
        self.f_tab.setRowCount(len(filas)); self._filas = []
        for i, (n, q) in enumerate(filas):
            w = a_wgs.transform(q); u = a_utm.transform(q)
            la = _gms(w.y(), 'N', 'S') if gms else '%.6f' % w.y()
            lo = _gms(w.x(), 'E', 'O') if gms else '%.6f' % w.x()
            vals = [n, la, lo, '%.0f' % u.x(), '%.0f' % u.y()]
            self._filas.append(vals)
            for j, t in enumerate(vals):
                it = QTableWidgetItem(t)
                if n == 'Centro': fnt = it.font(); fnt.setBold(True); it.setFont(fnt)
                self.f_tab.setItem(i, j, it)
        self.f_zona.setText('UTM zona %d%s, WGS 84 (%s). Superficie y longitud aproximadas.' % (zona, 'S' if c.y() < 0 else 'N', utm.authid()))

    # ---------- cambios ----------
    def _editar(self, capa):
        if not capa.isEditable(): capa.startEditing()

    def _terminar(self, capa):
        capa.triggerRepaint()
        if self.ck_guardar.isChecked(): _guardar(capa)
        self.cargar_ficha(); self.redibujar()

    def cambiar(self, campo, valor):
        if self._carga: return
        capa, f = self.elemento()
        if f is None: return
        i = capa.fields().indexOf(campo)
        if i < 0:
            iface.messageBar().pushMessage('Simbología', 'La capa no tiene el campo «%s».' % campo, Qgis.Warning, 6); return
        if f[campo] == valor: return
        self._editar(capa); capa.changeAttributeValue(f.id(), i, valor); self._terminar(capa)

    def aplicar_ajuste(self, aj):
        capa, f = self.elemento()
        if f is None: return
        self._editar(capa)
        if capa.name() == N_PTS:
            if aj[0] == 'mover':
                q = f.geometry().asPoint(); capa.changeGeometry(f.id(), QgsGeometry.fromPointXY(QgsPointXY(q.x() + aj[1], q.y() + aj[2])))
            elif aj[0] == 'tam': capa.changeAttributeValue(f.id(), capa.fields().indexOf('tamano'), float(round(aj[1])))
            elif aj[0] == 'giro': capa.changeAttributeValue(f.id(), capa.fields().indexOf('rotacion'), float(aj[1]))
        else:
            capa.changeGeometry(f.id(), self.ajustar.geom_ajustada(f.geometry(), aj))
        self._terminar(capa)

    def escalar(self, factor):
        capa, f = self.elemento()
        if f is None: return
        self._editar(capa)
        if capa.name() == N_PTS:
            capa.changeAttributeValue(f.id(), capa.fields().indexOf('tamano'), float(max(5, round(float(f['tamano'] or 600) * factor))))
        else:
            capa.changeGeometry(f.id(), self.ajustar.geom_ajustada(f.geometry(), ('escala', factor)))
        self._terminar(capa)

    def borrar(self):
        capa, f = self.elemento()
        if f is None: return
        self._editar(capa); capa.deleteFeature(f.id()); self.sel = (None, None)
        self._terminar(capa)

    def copiar(self):
        capa, f = self.elemento()
        if f is None: return
        cab = ['Punto', 'Latitud', 'Longitud', 'UTM Este', 'UTM Norte']
        txt = self.f_titulo.text() + '\n' + '\t'.join(cab) + '\n' + '\n'.join('\t'.join(r) for r in self._filas) + '\n' + self.f_zona.text()
        QGuiApplication.clipboard().setText(txt)
        iface.messageBar().pushMessage('Simbología', 'Coordenadas copiadas. Pégalas en Excel o Word.', Qgis.Success, 4)

    def centrar(self):
        capa, f = self.elemento()
        if f is None: return
        cv = iface.mapCanvas(); cv.setCenter(f.geometry().boundingBox().center()); cv.refresh()

    # ---------- colocar y dibujar ----------
    def doble(self, it, col):
        d = it.data(0, Qt.UserRole)
        if not d: return
        if d['k'] == 'p':
            self._pend = d; iface.mapCanvas().setMapTool(self.punto)
            iface.messageBar().pushMessage('Simbología', 'Haz clic en el mapa para colocar: ' + it.text(0), Qgis.Info, 5)
        else: self.dibujar(d)

    def _clic(self, pt, boton):
        if self._pend:
            d = self._pend; self._pend = None; self.soltar(d, pt)

    def soltar(self, d, pt):
        if d['k'] != 'p': self.dibujar(d); return
        l = _capa(N_PTS)
        if not l: return
        self._editar(l); cv = iface.mapCanvas()
        tam = round(cv.scale() * 0.012) if self.ck_auto.isChecked() else 600
        bando = d.get('bando', 'Propio')
        if bando == 'Propio': bando = self.cb_bando_n.currentData()
        f = QgsFeature(l.fields())
        f.setGeometry(QgsGeometry.fromPointXY(cv.mapSettings().mapToLayerCoordinates(l, pt)))
        f['simbolo'] = d['key']; f['bando'] = bando; f['tamano'] = float(tam); f['previsto'] = 0; f['rotacion'] = 0.0
        if l.fields().indexOf('opacidad') >= 0: f['opacidad'] = 100
        l.addFeature(f)
        if self.ck_guardar.isChecked(): _guardar(l)
        nuevo = max(l.allFeatureIds()) if f.id() < 0 else f.id()
        cv.setMapTool(self.ajustar); self.seleccionar(l, nuevo)

    def dibujar(self, d):
        l = _capa(N_LIN if d['k'] == 'l' else N_ZON)
        if not l: return
        self._editar(l)
        l.setDefaultValueDefinition(l.fields().indexOf('tipo'), QgsDefaultValue("'%s'" % d['tipo'].replace("'", "''")))
        l.setDefaultValueDefinition(l.fields().indexOf('bando'), QgsDefaultValue("'%s'" % self.cb_bando_n.currentData()))
        if l.fields().indexOf('opacidad') >= 0: l.setDefaultValueDefinition(l.fields().indexOf('opacidad'), QgsDefaultValue('100'))
        iface.setActiveLayer(l); iface.actionAddFeature().trigger()
        iface.messageBar().pushMessage('Simbología', 'Dibuja «%s»: clic izquierdo en cada punto, clic derecho para terminar.' % d['tipo'], Qgis.Info, 7)

    def nuevo_dibujo(self, nombre, fid):
        l = _capa(nombre)
        if l is None or nombre == N_PTS: return
        if self.ck_guardar.isChecked() and l.isEditable() and l.isModified():
            _guardar(l)
        ids = l.allFeatureIds()
        if ids:
            nuevo = fid if fid >= 0 and fid in ids else max(ids)
            iface.mapCanvas().setMapTool(self.ajustar); self.seleccionar(l, nuevo)

    def tocar(self, pos):
        pt = iface.mapCanvas().getCoordinateTransform().toMapCoordinates(pos.x(), pos.y())
        capa, fid = self.ajustar.elegir(pt)
        if fid is not None:
            iface.mapCanvas().setMapTool(self.ajustar); self.seleccionar(capa, fid)

    # ---------- exportar ----------
    def _carpeta(self, sub='SHAPES', propia=True):
        nombre = self.e_nombre.text().strip() or 'Calco'
        seguro = re.sub(r'[^\w\-]+', '_', nombre).strip('_') or 'Calco'
        out = os.path.join(self.home, sub, seguro if propia else '').replace('\\', '/').rstrip('/')
        os.makedirs(out, exist_ok=True)
        return nombre, seguro, out

    def _guardar_todo(self):
        for n in (N_PTS, N_LIN, N_ZON):
            if not _guardar(_capa(n)): return False
        return True

    def exportar_shape(self):
        if not self._guardar_todo(): return
        nombre, seguro, out = self._carpeta()
        py = [os.path.join(sys.exec_prefix, 'python.exe')] + glob.glob(os.path.join(os.path.dirname(sys.executable), '..', 'apps', 'Python*', 'python.exe'))
        py = [x for x in py if os.path.exists(x)]
        if not py:
            self.e_estado.setText('No se encontró el Python de QGIS para exportar.'); return
        src = os.path.join(self.home, 'PLANEAMIENTO.gpkg').replace('\\', '/')
        codigo = ("from osgeo import gdal\ngdal.UseExceptions()\n"
                  "src=r'%s'\n"
                  "for capa,nom in (('simbolos_militares','simbolos'),('lineas_tacticas','lineas'),('zonas_tacticas','zonas')):\n"
                  "    ds=gdal.OpenEx(src); n=ds.GetLayerByName(capa).GetFeatureCount(); ds=None\n"
                  "    if n==0: continue\n"
                  "    gdal.VectorTranslate(r'%s/%s_'+nom+'.shp',src,layers=[capa],format='ESRI Shapefile',accessMode='overwrite',layerCreationOptions=['ENCODING=UTF-8'])\n"
                  "    print(nom,n)\n") % (src, out, seguro)
        try:
            r = subprocess.run([py[0], '-c', codigo], capture_output=True, text=True, timeout=120, creationflags=0x08000000)
        except subprocess.TimeoutExpired:
            self.e_estado.setText('La exportación tardó demasiado. Vuelve a intentarlo.'); return
        if r.returncode != 0:
            self.e_estado.setText('No se pudo guardar el shape: ' + r.stderr.strip().splitlines()[-1] if r.stderr.strip() else 'error desconocido'); return
        partes = [l.split() for l in r.stdout.strip().splitlines() if l.strip()]
        try:
            self._completar_paquete(nombre, seguro, out, dict(partes))
        except Exception as e:
            self.e_estado.setText('Shape guardado, pero falló el paquete completo: %s' % e); return
        txt = ', '.join('%s (%s)' % (a, b) for a, b in partes) or 'no hay figuras'
        self.e_estado.setText('Paquete guardado en %s y %s.zip: %s.' % (out, out, txt))
        iface.messageBar().pushMessage('Simbología', 'Shape «%s» guardado.' % nombre, Qgis.Success, 5)

    def _completar_paquete(self, nombre, seguro, out, hechos):
        mapa = {'simbolos': N_PTS, 'lineas': N_LIN, 'zonas': N_ZON}
        for corto, capa_n in mapa.items():
            if corto not in hechos: continue
            qml = '%s/%s_%s.qml' % (out, seguro, corto)
            _capa(capa_n).saveNamedStyle(qml)
            t = open(qml, encoding='utf-8').read()
            t = t.replace('texto_centro', 'texto_cent').replace('texto_abajo', 'texto_abaj')
            t = t.replace("@project_home || '/simbolos/'", "file_path(layer_property(@layer,'path')) || '/simbolos/'")
            open(qml, 'w', encoding='utf-8').write(t)
        if os.path.isdir(out + '/simbolos'): shutil.rmtree(out + '/simbolos')
        shutil.copytree(os.path.join(self.home, 'simbolos'), out + '/simbolos')
        # coordenadas de todas las figuras
        with open('%s/%s_coordenadas.csv' % (out, seguro), 'w', newline='', encoding='utf-8-sig') as fh:
            w = csv.writer(fh, delimiter=';')
            w.writerow(['Capa', 'N.º', 'Figura', 'Bando', 'Escalón / nombre', 'Designación', 'Punto', 'Latitud', 'Longitud', 'UTM Este', 'UTM Norte', 'Zona UTM'])
            for capa_n in (N_PTS, N_LIN, N_ZON):
                capa = _capa(capa_n)
                for f in capa.getFeatures():
                    if f.geometry().isNull(): continue
                    if capa_n == N_PTS:
                        fig = self.nombre.get(f['simbolo'], f['simbolo']); es = f['escalon'] or ''
                        de = ' '.join(str(f[k]) for k in ('desig_izq', 'desig_der') if f[k] not in (None, '') and str(f[k]) != 'NULL')
                    else:
                        fig = f['tipo']; es = f['etiqueta'] if f['etiqueta'] not in (None,) and str(f['etiqueta']) != 'NULL' else ''; de = f['fecha_hora'] if f['fecha_hora'] not in (None,) and str(f['fecha_hora']) != 'NULL' else ''
                    c = QgsCoordinateTransform(capa.crs(), WGS, QgsProject.instance()).transform(f.geometry().boundingBox().center())
                    ep = (32700 if c.y() < 0 else 32600) + int((c.x() + 180) // 6) + 1
                    a_w = QgsCoordinateTransform(capa.crs(), WGS, QgsProject.instance())
                    a_u = QgsCoordinateTransform(capa.crs(), QgsCoordinateReferenceSystem('EPSG:%d' % ep), QgsProject.instance())
                    for pn, q in self.puntos(capa, f):
                        g = a_w.transform(q); u = a_u.transform(q)
                        w.writerow([capa_n, f.id(), fig, f['bando'], es, de, pn, '%.6f' % g.y(), '%.6f' % g.x(), '%.0f' % u.x(), '%.0f' % u.y(), '%d%s' % (ep % 100, 'S' if ep > 32700 else 'N')])
        leeme = ('PAQUETE DE SHAPES · %s\n' % nombre +
                 'Proyecto PLANEAMIENTO · generado el %s\n\n' % datetime.datetime.now().strftime('%d/%m/%Y %H:%M') +
                 'Contenido:\n' + ''.join('  %s_%s.shp  (%s figuras)\n' % (seguro, k, v) for k, v in hechos.items()) +
                 '  *.qml                 estilo con la simbología militar (QGIS lo aplica solo)\n'
                 '  simbolos/             dibujos de los símbolos; no separar de los .shp\n'
                 '  %s_coordenadas.csv    coordenadas de cada figura: centro y cada punto (WGS 84 y UTM)\n\n' % seguro +
                 'Sistema de coordenadas de los shapes: EPSG:3857 (WGS 84 / Pseudo-Mercator).\n'
                 'Para abrir en QGIS: arrastra los .shp al mapa. Mantén todos los archivos en la misma carpeta.\n'
                 'Colores: azul propio, rojo enemigo (unidades en rombo), verde obstáculos, amarillo contaminado, negro obras.\n')
        open('%s/LEEME.txt' % out, 'w', encoding='utf-8').write(leeme)
        z = out + '.zip'
        with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as zf:
            for raiz, _, archivos in os.walk(out):
                for a in archivos:
                    ruta = os.path.join(raiz, a); zf.write(ruta, os.path.relpath(ruta, os.path.dirname(out)))

    def exportar_carta(self):
        if not self._guardar_todo(): return
        nombre, seguro, out = self._carpeta('CARTAS', False)
        p = QgsProject.instance(); cv = iface.mapCanvas()
        capas = [l for l in (_capa(N_PTS), _capa(N_LIN), _capa(N_ZON)) if l]
        if self.e_area.currentIndex() == 1:
            ext = QgsRectangle()
            for l in capas:
                for f in l.getFeatures(): ext.combineExtentWith(f.geometry().boundingBox())
            if ext.isNull() or ext.isEmpty(): ext = QgsRectangle(cv.extent())
            else: ext.grow(max(ext.width(), ext.height(), 1000) * 0.08)
        else:
            ext = QgsRectangle(cv.extent())
        visibles = [n.layer() for n in p.layerTreeRoot().findLayers() if n.isVisible() and n.layer() is not None]
        L = QgsPrintLayout(p); L.initializeDefaults(); L.setName('Carta ' + nombre)
        L.pageCollection().page(0).setPageSize('A4', QgsLayoutItemPage.Landscape)
        mm = lambda x, y: QgsLayoutPoint(x, y, QgsUnitTypes.LayoutMillimeters)
        sz = lambda w, h: QgsLayoutSize(w, h, QgsUnitTypes.LayoutMillimeters)
        def texto(t, x, y, w, h, pt, bold=False, al=Qt.AlignLeft):
            it = QgsLayoutItemLabel(L); it.setText(t); fm = QgsTextFormat(); f = QFont('Arial'); f.setBold(bold); fm.setFont(f); fm.setSize(pt)
            it.setTextFormat(fm); it.setHAlign(al); it.attemptMove(mm(x, y)); it.attemptResize(sz(w, h)); L.addLayoutItem(it); return it
        texto(nombre.upper(), 12, 6, 220, 9, 16, True)
        texto('Proyecto %s · Calco de operaciones · %s' % (p.title() or 'PLANEAMIENTO', datetime.date.today().strftime('%d/%m/%Y')), 12, 14, 220, 6, 9)
        M = QgsLayoutItemMap(L); M.attemptMove(mm(12, 22)); M.attemptResize(sz(273, 158))
        M.setLayers(visibles); M.setCrs(p.crs()); M.zoomToExtent(ext); M.setFrameEnabled(True); L.addLayoutItem(M)
        utm = QgsCoordinateReferenceSystem('EPSG:%d' % self._zona_epsg(ext.center()))
        g = QgsLayoutItemMapGrid('UTM', M); g.setCrs(utm)
        a_utm = QgsCoordinateTransform(p.crs(), utm, p).transformBoundingBox(ext)
        raw = a_utm.width() / 6; b = 10 ** math.floor(math.log10(raw)); iv = [k * b for k in (1, 2, 5, 10) if k * b >= raw][0]
        g.setIntervalX(iv); g.setIntervalY(iv); g.setStyle(QgsLayoutItemMapGrid.Solid)
        g.setLineSymbol(QgsLineSymbol.createSimple({'color': '255,255,255,150', 'width': '0.2'}))
        g.setAnnotationEnabled(True); g.setAnnotationPrecision(0)
        af = QgsTextFormat(); af.setFont(QFont('Arial')); af.setSize(6.5); g.setAnnotationTextFormat(af)
        for lado in (QgsLayoutItemMapGrid.Left, QgsLayoutItemMapGrid.Right, QgsLayoutItemMapGrid.Top, QgsLayoutItemMapGrid.Bottom):
            g.setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, lado)
        g.setAnnotationDirection(QgsLayoutItemMapGrid.Vertical, QgsLayoutItemMapGrid.Left); g.setAnnotationDirection(QgsLayoutItemMapGrid.Vertical, QgsLayoutItemMapGrid.Right)
        g.setFrameStyle(QgsLayoutItemMapGrid.Zebra); g.setFrameWidth(1.5); M.grids().addGrid(g)
        ancho_km = a_utm.width() / 1000.0; seg = ancho_km / 10; bs = 10 ** math.floor(math.log10(seg)); seg = [k * bs for k in (1, 2, 5, 10) if k * bs >= seg][0]
        sb = QgsLayoutItemScaleBar(L); sb.setStyle('Single Box'); sb.setLinkedMap(M)
        sb.setUnits(QgsUnitTypes.DistanceKilometers); sb.setUnitLabel('km'); sb.setSegmentSizeMode(QgsScaleBarSettings.SegmentSizeFixed)
        sb.setUnitsPerSegment(seg); sb.setNumberOfSegments(4); sb.setNumberOfSegmentsLeft(0); sb.setHeight(2.5)
        fm = QgsTextFormat(); fm.setFont(QFont('Arial')); fm.setSize(7); sb.setTextFormat(fm)
        sb.attemptMove(mm(12, 186)); L.addLayoutItem(sb); sb.update()
        na = QgsLayoutItemPicture(L); na.setPicturePath(QgsSymbolLayerUtils.svgSymbolNameToPath('arrows/NorthArrow_02.svg', QgsPathResolver()))
        na.attemptMove(mm(268, 184)); na.attemptResize(sz(12, 16)); L.addLayoutItem(na)
        ep = utm.postgisSrid(); zona = '%d%s' % (ep % 100, 'S' if ep > 32700 else 'N')
        texto('Escala aprox. 1:%s\nCuadrícula UTM zona %s (WGS 84) cada %s m\nBase: imagen satelital Esri' % (
            format(int(round(M.scale(), -2)), ',').replace(',', '.'), zona, format(int(iv), ',').replace(',', '.')), 150, 189, 110, 16, 7.5, False, Qt.AlignRight)
        ex = QgsLayoutExporter(L)
        s1 = QgsLayoutExporter.ImageExportSettings(); s1.dpi = 200
        png = '%s/%s_carta.png' % (out, seguro); pdf = '%s/%s_carta.pdf' % (out, seguro)
        r1 = ex.exportToImage(png, s1); r2 = ex.exportToPdf(pdf, QgsLayoutExporter.PdfExportSettings())
        if r1 == QgsLayoutExporter.Success and r2 == QgsLayoutExporter.Success:
            self.e_estado.setText('Carta guardada en %s como %s_carta.png y .pdf.' % (out, seguro))
            iface.messageBar().pushMessage('Simbología', 'Carta «%s» guardada.' % nombre, Qgis.Success, 5)
        else:
            self.e_estado.setText('No se pudo guardar la carta (código %s / %s). Revisa que el archivo no esté abierto en otro programa.' % (r1, r2))

    def _zona_epsg(self, c):
        w = QgsCoordinateTransform(QgsProject.instance().crs(), WGS, QgsProject.instance()).transform(c)
        return (32700 if w.y() < 0 else 32600) + int((w.x() + 180) // 6) + 1

    def abrir_carpeta(self):
        d = os.path.join(self.home, 'SHAPES'); os.makedirs(d, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(d))

    def activar_ajuste(self):
        iface.mapCanvas().setMapTool(self.ajustar)

    def guardar(self):
        n = 0
        for nombre in (N_PTS, N_LIN, N_ZON):
            l = _capa(nombre)
            if l and l.isEditable() and l.isModified() and _guardar(l): n += 1
        QgsProject.instance().write()
        iface.messageBar().pushMessage('Simbología', 'Guardado: %d capa(s) y el proyecto.' % n, Qgis.Success, 4)

    def cerrar(self):
        cv = iface.mapCanvas()
        try:
            cv.viewport().removeEventFilter(self.filtro); cv.removeEventFilter(self.filtro)
            if cv.mapTool() in (self.ajustar, self.punto): cv.unsetMapTool(cv.mapTool())
            self.ajustar.ocultar()
            for s, f in self._con:
                try: s.disconnect(f)
                except Exception: pass
        except Exception:
            pass
        iface.removeDockWidget(self); self.deleteLater()


def iniciar_panel():
    viejo = getattr(_qu, '_panel_simbologia_militar', None)
    if viejo is not None:
        try: viejo.cerrar()
        except Exception: pass
    p = Panel()
    iface.addDockWidget(Qt.RightDockWidgetArea, p)
    _qu._panel_simbologia_militar = p
    return p


iniciar_panel()
